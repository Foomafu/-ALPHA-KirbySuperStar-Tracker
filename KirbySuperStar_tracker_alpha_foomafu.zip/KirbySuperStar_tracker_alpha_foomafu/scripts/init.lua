--- KSS Randomizer Tracker Init

--- LUA Scripts
ScriptHost:LoadScript("scripts/control.lua")

--- Items
Tracker:AddItems("items/abilities.json")
Tracker:AddItems("items/subgames.json")
Tracker:AddItems("items/items_maps.json")
Tracker:AddItems("items/gcot.json")
Tracker:AddItems("items/mwws.json")
Tracker:AddItems("items/check_host.json")


--- Maps
Tracker:AddMaps("maps/maps.json")

--- Layouts
Tracker:AddLayouts("layouts/ability_grid.json")
Tracker:AddLayouts("layouts/mwws_grid.json")
Tracker:AddLayouts("layouts/subgames_grid.json")
Tracker:AddLayouts("layouts/gcot_grid.json")

Tracker:AddLayouts("layouts/maps/coarkboard.json")
Tracker:AddLayouts("layouts/maps/dynablade.json")
Tracker:AddLayouts("layouts/maps/thegreatcaveoffensive.json")
Tracker:AddLayouts("layouts/maps/milkywaywishes.json")

Tracker:AddLayouts("layouts/maps.json")

--if Tracker.ActiveVariantUID == "standard" then
    Tracker:AddLayouts("layouts/tracker.json")
--elseif Tracker.ActiveVariantUID == "compact" then
--    Tracker:AddLayouts("compact/layouts/tracker.json")
--end

--- Locations
if Tracker.ActiveVariantUID == "standard" or Tracker.ActiveVariantUID == "compact" then
    Tracker:AddLocations("locations/coarkboard.json")
    Tracker:AddLocations("locations/dynablade.json")
    Tracker:AddLocations("locations/milkywaywishes.json")
    Tracker:AddLocations("locations/thegreatcaveoffensive.json")
end
