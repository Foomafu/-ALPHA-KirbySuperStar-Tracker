# Kirby Super Star Randomizer Tracker

## About

This is an [EmoTracker](https://emotracker.net/) pack for tracking progress in the Kirby Super Star Randomizer.

## Release Notes

- Author: Foomafu

<details open="open">
<summary>Version 0.0.1</summary>

- TODO: Write this

</details>

## License

This program is licensed under the GNU General Public License v2.0.